# Packaging Python and using GitHub as a private (PyPI) server

This tutorial is a summarization of the following resources:

- https://medium.com/network-letters/using-github-as-a-private-python-package-index-server-798a6e1cfdef

- https://packaging.python.org/en/latest/tutorials/packaging-projects/#generating-distribution-archives

- https://packaging.python.org/en/latest/guides/writing-pyproject-toml/

- https://packaging.python.org/en/latest/specifications/pypirc/

- https://stackoverflow.com/questions/9727673/list-directory-tree-structure-in-python

